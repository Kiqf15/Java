/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package appstrategyloan;

import java.util.Date;

/**
 *
 * @author orlandojunior
 */
public class Payment {

    private double amount;
    private Date date;

    public Payment() {
        this.amount = 0.0;
        this.date = new Date();
    }

    public Payment(double amount, Date date) {
        this.amount = amount;
        this.date = date;
    }

    public double getAmount() {
        return amount;
    }

    private void setAmount(double amount) {
        this.amount = amount;
    }

    public Date getDate() {
        return date;
    }

    private void setDate(Date date) {
        this.date = date;
    }

}
