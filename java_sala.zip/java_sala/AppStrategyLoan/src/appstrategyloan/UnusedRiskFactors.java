/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package appstrategyloan;

/**
 *
 * @author orlandojunior
 */
public class UnusedRiskFactors {

    private UnusedRiskFactors() {

    }

    public static UnusedRiskFactors getFactors() {
        return new UnusedRiskFactors();
    }

    public double forRating(double riskRating) {
        return 0.01;
    }
}
