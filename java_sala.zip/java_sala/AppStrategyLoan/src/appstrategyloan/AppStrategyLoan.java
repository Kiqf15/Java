package appstrategyloan;

import java.util.Date;

/**
 *
 * @author orlandojunior
 */
public class AppStrategyLoan {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    }
}
