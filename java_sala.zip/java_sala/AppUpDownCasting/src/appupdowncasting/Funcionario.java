package appupdowncasting;

/**
 *
 * @author osjunior
 */
public class Funcionario {

    public void batePonto() {
        System.out.println("Funcionário entrou...");
    }
}
