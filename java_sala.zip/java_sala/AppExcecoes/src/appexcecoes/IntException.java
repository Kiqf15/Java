package appexcecoes;

/**
 *
 * @author osjunior
 */
public class IntException extends RuntimeException {

    public IntException(String message) {
        super(message);
    }
    
}
