package appexcecoes;

import java.util.Scanner;

/**
 *
 * @author osjunior
 */
public class AppExcecoes {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            daExcecao();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }

    private static void daExcecao() throws Exception {
        chamaExcecao();
    }

    private static void chamaExcecao() throws Exception {
        Integer[] itens = new Integer[10];

        int i;
        for (i = 0; i < itens.length; i++) {
            itens[i] = i;
        }
        
        for (i = 0; i <= itens.length; i++) {
            
            if (i == 5)
                throw new IntException("Chegou no i = 5");
            
            System.out.println("i = " + itens[i]);
        }
    }
}
