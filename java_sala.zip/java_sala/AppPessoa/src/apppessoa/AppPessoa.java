package apppessoa;

import java.util.Scanner;

/**
 *
 * @author osjunior
 */
public class AppPessoa {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Leitura
        Scanner input = new Scanner(System.in);

        // P1
        Pessoa p1 = new Pessoa();
        System.out.print("Nome: ");
        p1.setNome(input.nextLine());
        System.out.print("CPF: ");
        p1.setCpf(input.nextLine());
        System.out.print("Idade: ");
        p1.setIdade(input.nextInt());
        
        input.nextLine();

        // P2
        Pessoa p2 = new Pessoa();
        System.out.print("Nome: ");
        p2.setNome(input.nextLine());
        System.out.print("CPF: ");
        p2.setCpf(input.nextLine());
        System.out.print("Idade: ");
        p2.setIdade(input.nextInt());
                
        input.nextLine();

        // P3
        Pessoa p3 = new Pessoa();
        System.out.print("Nome: ");
        p3.setNome(input.nextLine());
        System.out.print("CPF: ");
        p3.setCpf(input.nextLine());
        System.out.print("Idade: ");
        p3.setIdade(input.nextInt());

    }

}
