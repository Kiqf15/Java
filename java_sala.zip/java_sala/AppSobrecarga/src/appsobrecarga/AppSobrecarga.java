/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package appsobrecarga;

/**
 *
 * @author osjunior
 */
public class AppSobrecarga {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Calculadora c = new Calculadora();
        System.out.println("Soma inteiros = " + c.square(10));
        System.out.println("Soma decimais = " + c.square(20.5));
        System.out.println(c);
    }    
}
