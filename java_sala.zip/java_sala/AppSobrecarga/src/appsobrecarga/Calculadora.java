package appsobrecarga;

/**
 *
 * @author osjunior
 */
public class Calculadora {

    public int square(int n) {
        return n * n;
    }

    public double square(double n) {
        return n * n;
    }

    @Override
    public String toString() {
        // Sobrescrita do método toString()
        // da classe Object.
        return "Calculadora";
    }
}
