   /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package appescolaheranca;

import java.util.Scanner;
import java.util.ArrayList;

/**
 *
 * @author osjunior
 */
public class AppEscolaHeranca {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList<Aluno> alunos = new ArrayList<>();

        Scanner input = new Scanner(System.in);

        System.out.print("Nome: ");
        String nome = input.nextLine();

        System.out.print("Sobrenome: ");
        String sobrenome = input.nextLine();

        System.out.print("Idade: ");
        int idade = input.nextInt();

        input.nextLine();
        
        System.out.print("Curso: ");
        String curso = input.nextLine();

        Aluno objAluno = new Aluno(nome, sobrenome, idade, curso);
        alunos.add(objAluno);

        for (Aluno a : alunos) {
            System.out.println(a);
        }
    }
}
