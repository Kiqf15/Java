/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package apparraylists;

import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author osjunior
 */
public class AppArrayLists {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList<Pessoa> p;
        p = new ArrayList<>();

        p.add(new Pessoa("João", 18));
        p.add(new Pessoa("Maria", 19));
        p.add(new Pessoa("Carlos", 20));

        // For
        for (int i = 0; i < p.size(); i++) {
            Pessoa pp = p.get(i);
            System.out.println("Nome : " + pp.getNome());
            System.out.println("Idade: " + pp.getIdade());
            System.out.println();
        }

        // For-each
        for (Pessoa pp : p) {
            System.out.println("Nome : " + pp.getNome());
            System.out.println("Idade: " + pp.getIdade());
            System.out.println();
        }

        // Iterator
        Iterator<Pessoa> itr = p.iterator();
        while (itr.hasNext()) {
            Pessoa pp = itr.next();
            System.out.println("Nome : " + pp.getNome());
            System.out.println("Idade: " + pp.getIdade());
            System.out.println();
        }

        // PessoaCollection
        PessoaCollection pc = new PessoaCollection();
        pc.adiciona(new Pessoa("João", 18));
        pc.adiciona(new Pessoa("Maria", 19));
        pc.adiciona(new Pessoa("Carlos", 20));
        pc.mostra();
    }
}
