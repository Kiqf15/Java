/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package apparraylists;

import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author osjunior
 */
public class PessoaCollection {

    private ArrayList<Pessoa> lista;

    public PessoaCollection() {
        this.lista = new ArrayList<>();
    }

    public void adiciona(Pessoa p) {
        lista.add(p);
    }

    public void mostra() {
        Iterator<Pessoa> itr = lista.iterator();
        while (itr.hasNext()) {
            Pessoa pp = itr.next();
            System.out.println("Nome : " + pp.getNome());
            System.out.println("Idade: " + pp.getIdade());
            System.out.println();
        }
    }
}
