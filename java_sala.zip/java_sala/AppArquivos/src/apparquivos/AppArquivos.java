package apparquivos;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author osjunior
 */
public class AppArquivos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //escreveArquivo();
        leArquivo();
    }

    private static void escreveArquivo() {
        try {
            FileWriter arquivo = new FileWriter("impares.txt", true);
            PrintWriter escritaArquivo = new PrintWriter(arquivo);

            for (int i = 1; i < 100; i++) {
                if (i % 2 != 0) {
                    escritaArquivo.println(i);
                }
            }

            arquivo.close();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }

    private static void leArquivo() {
        try {
            FileReader arquivo = new FileReader("impares.txt");
            BufferedReader br = new BufferedReader(arquivo);

            String linha;
            while ((linha = br.readLine()) != null) {
                System.out.println(linha);
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }
}
