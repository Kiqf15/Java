/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package appgenerics;

/**
 *
 * @author osjunior
 */
public class AppGenerics {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Calculadora<Double> calc = new Calculadora<Double>(2.5, 4.2);
        Double resultado = calc.soma();
        System.out.println("Resultado = " + resultado);
    }
}
