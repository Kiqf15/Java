package appgenerics;

/**
 *
 * @author osjunior
 * @param <T>
 */
public class Calculadora<T extends Number> {

    private T a;
    private T b;

    public Calculadora(T a, T b) {
        this.a = a;
        this.b = b;
    }

    public T soma() {
        if (a instanceof Integer && b instanceof Integer) {
            return (T)new Integer(this.a.intValue() + this.b.intValue());
        } else if (a instanceof Double && b instanceof Double){
            return (T)new Double(this.a.doubleValue() + this.b.doubleValue());
        }
        return null;
    }
}
