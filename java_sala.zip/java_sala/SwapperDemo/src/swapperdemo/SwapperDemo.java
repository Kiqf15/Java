package swapperdemo;

import java.util.Scanner;

/**
 *
 * @author osjunior
 */
public class SwapperDemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Swapper troca = new Swapper();

        Scanner input = new Scanner(System.in);

        System.out.print("X = ");
        troca.setX(input.nextFloat());
        System.out.print("Y = ");
        troca.setY(input.nextFloat());

        troca.swap();

        System.out.println("Novo X = " + troca.getX());
        System.out.println("Novo Y = " + troca.getY());

    }
}
