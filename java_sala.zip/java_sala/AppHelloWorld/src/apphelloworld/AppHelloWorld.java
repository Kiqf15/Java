package apphelloworld;

import java.util.Scanner;
import java.lang.Math;

public class AppHelloWorld {

    public static void main(String[] args) {
        int a, b, c;
        int aux;

        Scanner input = new Scanner(System.in);

        /* Entrada */
        System.out.print("A: ");
        a = input.nextInt();

        System.out.print("B: ");
        b = input.nextInt();

        System.out.print("C: ");
        c = input.nextInt();

        /* Processamento */
        if (a > b) {
            aux = a;
            a = b;
            b = aux;
        }
        if (a > c) {
            aux = a;
            a = c;
            c = aux;
        }
        if (b > c) {
            aux = b;
            b = c;
            c = aux;
        }

        /* Saída */
        System.out.println();
        System.out.printf("A: %d\n", a);
        System.out.printf("B: %d\n", b);
        System.out.printf("C: %d\n", c);
    }
}
