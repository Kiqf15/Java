package appalunosbd;

import appalunosbd.model.Aluno;
import appalunosbd.dal.AlunoDAO;
import appalunosbd.view.FrmPrincipal;
import java.util.ArrayList;

/**
 *
 * @author osjunior
 */
public class AppAlunosBD {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        FrmPrincipal frm = new FrmPrincipal();
        frm.setVisible(true);
    }
}
