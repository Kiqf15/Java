package appmetaclassereflection;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import minhasclasses.Pessoa;

/**
 *
 * @author osjunior
 */
public class AppMetaclasseReflection {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Pessoa p = new Pessoa("João", 45);

        Class c = p.getClass();

        // Nome da classe e do pacote
        System.out.println(c.getName());
        System.out.println(c.getPackageName());

        // Nome dos atributos
        Field[] atributos = c.getDeclaredFields();
        for (Field attr : atributos) {
            System.out.println(attr.getName());
        }

        // Nome dos métodos
        Method[] metodos = c.getDeclaredMethods();
        for (Method m : metodos) {
            System.out.println(m.getName());
        }

        // Nome dos construtores
        Constructor[] construtores = c.getDeclaredConstructors();
        for (Constructor construtor : construtores) {
            System.out.println(construtor.getName());
            Parameter[] parametros = construtor.getParameters();
            for (Parameter parametro : parametros) {
                System.out.print("> ");
                System.out.println(parametro.getName());
            }
        }

        // Cria um novo objeto
        try {
            Class cls = Class.forName("minhasclasses.Pessoa");
            Object obj = cls.newInstance();
            Method metodo = cls.getDeclaredMethod("pagaImposto");
            metodo.invoke(obj);
        } catch (Exception ex) {
            System.out.println("Erro!");
        }

    }
}
