
package exemplograph;

public class ExemploGraph {

    public static void main(String[] args) {
        Janela j = new Janela();
        j.setVisible(true);
    }
    
}
