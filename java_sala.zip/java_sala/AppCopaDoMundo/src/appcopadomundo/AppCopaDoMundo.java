/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package appcopadomundo;

/**
 *
 * @author osjunior
 */
public class AppCopaDoMundo {
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Jogador j1 = new Jogador("Cristiano Ronaldo", "atacante", 7);
        System.out.println(j1.getNome());

        Jogador j2 = new Jogador("Lionel Messi", "atacante", 10);
        System.out.println(j2.getNome());
        
        
        
        
    }
}
