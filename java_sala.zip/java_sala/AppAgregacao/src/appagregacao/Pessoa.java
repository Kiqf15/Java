/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package appagregacao;

/**
 *
 * @author osjunior
 */
public class Pessoa {

    private String nome;
    private String endereco;
    private double renda;
    private java.util.Date data;
    private ContaComum conta;

    public void setConta(ContaComum conta) {
        this.conta = conta;
    }

    public ContaComum getConta() {
        return this.conta;
    }
}
