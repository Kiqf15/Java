/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.ArrayList;

/**
 *
 * @author kiq
 */
public class ResultadosProton {
    double funcaoIR, funcaoFR, funcaoIS, funcaoFS, ejip, ejfp, eevip, eevfp,
            energiaFotonProton, freqP, lambdaP, velIP, velFP, BroglieIP,BroglieFP,probabilidadeI,
            probabilidadeF, tratamento;
    private String operacoes;
    
    public ArrayList<Double> Operacoes(){
        ArrayList<Double> operacoes = new ArrayList<>();
        operacoes.add(this.getFuncaoIR());
        operacoes.add(this.getFuncaoFR());
        operacoes.add(this.getFuncaoIS());
        operacoes.add(this.getFuncaoFS());
        operacoes.add(this.getEjip());
        operacoes.add(this.getEjfp());
        operacoes.add(this.getEevip());
        operacoes.add(this.getEevfp());
        operacoes.add(this.getEnergiaFotonProton());
        operacoes.add(this.getFreqP());
        operacoes.add(this.getLambdaP());
        operacoes.add(this.getVelIP());
        operacoes.add(this.getVelFP());
        operacoes.add(this.getBroglieIP());
        operacoes.add(this.getBroglieFP());
        operacoes.add(this.getProbabilidadeI());
        operacoes.add(this.getProbabilidadeF());
        
        return operacoes;
    }
    
    public ArrayList<String> Tratamento(){
        ArrayList<String> tratamento = new ArrayList<>();
        tratamento.add("Função de onda quântica inicial (raiz): ");
        tratamento.add("Função de onda quântica final (raiz): ");
        tratamento.add("Função de onda quântica inicial (seno): ");
        tratamento.add("Função de onda quântica final (seno): ");
        tratamento.add("Energia em Joule do nível inicial de próton: ");
        tratamento.add("Energia em Joule do nível final de próton: ");
        tratamento.add("Energia em EletronVolts do nível inicial de próton: ");
        tratamento.add("Energia em EletronVolts do nível final de próton: ");
        tratamento.add("Energia do Foton em EletronVolts: ");
        tratamento.add("Frequência do próton: ");
        tratamento.add("Comprimento de onda do próton: ");
        tratamento.add("Velocidade inicial do próton: ");
        tratamento.add("Velocidade final do próton: ");
        tratamento.add("Comprimento de onda de De Broglie do próton (inicial): ");
        tratamento.add("Comprimento de onda de De Broglie do próton (final): ");
        tratamento.add("Probabilidade Inicial: ");
        tratamento.add("Probabilidade Final: ");
        
        return tratamento;
    }

    public ResultadosProton(double funcaoIR, double funcaoFR, double funcaoIS, double funcaoFS, double ejip, double ejfp, double eevip, double eevfp, double energiaFotonProton, double freqP, double lambdaP, double velIP, double velFP, double BroglieIP, double dBroglieFP, double probabilidadeI, double probabilidadeF) {
        this.funcaoIR = funcaoIR;
        this.funcaoFR = funcaoFR;
        this.funcaoIS = funcaoIS;
        this.funcaoFS = funcaoFS;
        this.ejip = ejip;
        this.ejfp = ejfp;
        this.eevip = eevip;
        this.eevfp = eevfp;
        this.energiaFotonProton = energiaFotonProton;
        this.freqP = freqP;
        this.lambdaP = lambdaP;
        this.velIP = velIP;
        this.velFP = velFP;
        this.BroglieIP = BroglieIP;
        this.BroglieFP = dBroglieFP;
        this.probabilidadeI = probabilidadeI;
        this.probabilidadeF = probabilidadeF;
    }
    
    public ResultadosProton() {
    }

    public double getFuncaoIR() {
        return funcaoIR;
    }

    public void setFuncaoIR(double funcaoIR) {
        this.funcaoIR = funcaoIR;
    }

    public double getFuncaoFR() {
        return funcaoFR;
    }

    public void setFuncaoFR(double funcaoFR) {
        this.funcaoFR = funcaoFR;
    }

    public double getFuncaoIS() {
        return funcaoIS;
    }

    public void setFuncaoIS(double funcaoIS) {
        this.funcaoIS = funcaoIS;
    }

    public double getFuncaoFS() {
        return funcaoFS;
    }

    public void setFuncaoFS(double funcaoFS) {
        this.funcaoFS = funcaoFS;
    }

    public double getEjip() {
        return ejip;
    }

    public void setEjip(double ejip) {
        this.ejip = ejip;
    }

    public double getEjfp() {
        return ejfp;
    }

    public void setEjfp(double ejfp) {
        this.ejfp = ejfp;
    }

    public double getEevip() {
        return eevip;
    }

    public void setEevip(double eevip) {
        this.eevip = eevip;
    }

    public double getEevfp() {
        return eevfp;
    }

    public void setEevfp(double eevfp) {
        this.eevfp = eevfp;
    }

    public double getEnergiaFotonProton() {
        return energiaFotonProton;
    }

    public void setEnergiaFotonProton(double energiaFotonProton) {
        this.energiaFotonProton = energiaFotonProton;
    }

    public double getFreqP() {
        return freqP;
    }

    public void setFreqP(double freqP) {
        this.freqP = freqP;
    }

    public double getLambdaP() {
        return lambdaP;
    }

    public void setLambdaP(double lambdaP) {
        this.lambdaP = lambdaP;
    }

    public double getVelIP() {
        return velIP;
    }

    public void setVelIP(double velIP) {
        this.velIP = velIP;
    }

    public double getVelFP() {
        return velFP;
    }

    public void setVelFP(double velFP) {
        this.velFP = velFP;
    }

    public double getBroglieIP() {
        return BroglieIP;
    }

    public void setBroglieIP(double BroglieIP) {
        this.BroglieIP = BroglieIP;
    }

    public double getBroglieFP() {
        return BroglieFP;
    }

    public void setBroglieFP(double dBroglieFP) {
        this.BroglieFP = dBroglieFP;
    }

    public double getProbabilidadeI() {
        return probabilidadeI;
    }

    public void setProbabilidadeI(double probabilidadeI) {
        this.probabilidadeI = probabilidadeI;
    }

    public double getProbabilidadeF() {
        return probabilidadeF;
    }

    public void setProbabilidadeF(double probabilidadeF) {
        this.probabilidadeF = probabilidadeF;
    }

    public double getTratamento() {
        return tratamento;
    }

    public void setTratamento(double tratamento) {
        this.tratamento = tratamento;
    }

    public String getOperacoes() {
        return operacoes;
    }

    public void setOperacoes(String operacoes) {
        this.operacoes = operacoes;
    }
    
    
    
}
