/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import java.awt.Color;
import java.awt.Graphics;
import pkg222210114_kaique_fernandes_projeto.view.Anima;

/**
 *
 * @author kiq
 */
public class Animacao {
    private Anima anima;

    public Animacao(Anima anima) {
        this.anima = anima;
    }

    public void anima(){
        Graphics g = anima.getCanvas2().getGraphics();
        Thread animaThread;
        animaThread = new Thread(new Runnable() {
            @Override
            public void run(){
                
                for(int y = 150; y < 550; y++){
                    // RETANGULO
                    g.setColor(Color.black);
                    g.drawLine(150, 100, 150, 550);
                    g.drawLine(550, 100, 550, 550);
                    g.drawLine(150, 100, 550, 100);
                    g.drawLine(150, 550, 550, 550);
                    // LINHA VERMELHA
                    g.setColor(Color.red);
                    g.drawLine(150, 530, 550, 530);
                    g.drawString("n = 1", 100, 515);
                    g.drawString("E1", 570, 515);
                    // LINHA CYAN
                    g.setColor(Color.cyan);
                    g.drawLine(150, 470, 550, 470);
                    g.drawString("n = 2", 100, 455);
                    g.drawString("E2", 570, 455);
                    // LINHA VERDE
                    g.setColor(Color.green);
                    g.drawLine(150, 370, 550, 370);
                    g.drawString("n = 3", 100, 355);
                    g.drawString("E3", 570, 355);
                    // LINHA LARANJA 
                    g.setColor(Color.orange);
                    g.drawLine(150, 250, 550, 250);
                    g.drawString("n = 4", 100, 235);
                    g.drawString("E4", 570, 235);
                    // LINHA MAGENTA
                    g.setColor(Color.MAGENTA);
                    g.drawLine(150, 130, 550, 130);
                    g.drawString("n = 5", 100, 115);
                    g.drawString("E5", 570, 115);

                }
                // LINHA VERMELHA
                for (int x = 150; x < 350; x++) {
                    g.setColor(Color.black);
                    g.fillOval(x, 525, 10, 10);
                    g.setColor(Color.yellow);
                    g.fillOval(-1 * (x - 660), 525, 30, 15);
                    try {
                        Thread.sleep(40);
                        g.setColor(Color.white);
                        g.fillOval(x, 525, 10, 10);
                        g.fillOval(-1 * (x - 660), 525, 30, 15);
                        g.setColor(Color.red);
                        g.drawLine(x, 530, 550, 530);

                    } catch (Exception e) {
                        System.err.println("" + e.getMessage());
                    }
                }
                
                // LINHA MAGENTA
                for (int x = 150; x < 540; x++) {
                    g.setColor(Color.red);
                    g.drawLine(x, 530, 550, 530);
                    g.setColor(Color.black);
                    g.fillOval(x, 125, 10, 10);
                    try {
                        Thread.sleep(3);
                        g.setColor(Color.white);
                        g.fillOval(x, 125, 10, 10);
                        g.setColor(Color.magenta);
                        g.drawLine(x, 130, 550, 130);

                    } catch (Exception e) {
                        System.err.println("" + e.getMessage());
                    }

                }
                for (int x = 550; x < 750; x++) {
                    g.setColor(Color.yellow);
                    g.fillOval(x, 125, 30, 15);
                    try {
                        Thread.sleep(7);
                        g.setColor(Color.white);
                        g.fillOval(x, 125, 30, 15);

                    } catch (Exception e) {
                        System.err.println("" + e.getMessage());
                    }

                }
                
                // LINHA LARANJA
                for (int x = 150; x < 540; x++) {
                    g.setColor(Color.black);
                    g.fillOval(x, 245, 10, 10);
                    try {
                        Thread.sleep(8);
                        g.setColor(Color.white);
                        g.fillOval(x, 245, 10, 10);
                        g.setColor(Color.orange);
                        g.drawLine(x, 250, 550, 250);

                    } catch (Exception e) {
                        System.err.println("" + e.getMessage());
                    }

                }
                
                for (int x = 550; x < 750; x++) {
                    g.setColor(Color.yellow);
                    g.fillOval(x, 245, 30, 15);
                    try {
                        Thread.sleep(7);
                        g.setColor(Color.white);
                        g.fillOval(x, 245, 30, 15);

                    } catch (Exception e) {
                        System.err.println("" + e.getMessage());
                    }

                }
                // LINHA VERDE
                for (int x = 150; x < 540; x++) {
                    g.setColor(Color.black);
                    g.fillOval(x, 365, 10, 10);
                    try {
                        Thread.sleep(20);
                        g.setColor(Color.white);
                        g.fillOval(x, 365, 10, 10);
                        g.setColor(Color.green);
                        g.drawLine(x, 370, 550, 370);

                    } catch (Exception e) {
                        System.err.println("" + e.getMessage());
                    }

                }

                for (int x = 550; x < 750; x++) {
                    g.setColor(Color.yellow);
                    g.fillOval(x, 365, 30, 15);
                    try {
                        Thread.sleep(7);
                        g.setColor(Color.white);
                        g.fillOval(x, 365, 30, 15);

                    } catch (Exception e) {
                        System.err.println("" + e.getMessage());
                    }

                }
                // LINHA CYAN
                for (int w = 150; w < 540; w++) {
                    g.setColor(Color.black);
                    g.fillOval(w, 465, 10, 10);
                    try {
                        Thread.sleep(30);
                        g.setColor(Color.white);
                        g.fillOval(w, 465, 10, 10);
                        g.setColor(Color.cyan);
                        g.drawLine(w, 470, 550, 470);

                    } catch (Exception e) {
                        System.err.println("" + e.getMessage());
                    }

                }
                for (int x = 550; x < 750; x++) {
                    g.setColor(Color.yellow);
                    g.fillOval(x, 465, 30, 15);
                    try {
                        Thread.sleep(7);
                        g.setColor(Color.white);
                        g.fillOval(x, 465, 30, 15);

                    } catch (Exception e) {
                        System.err.println("" + e.getMessage());
                    }

                }
                // LINHA VERMELHA
                for (int x = 150; x < 540; x++) {
                    g.setColor(Color.black);
                    g.fillOval(x, 525, 10, 10);
                    try {
                        Thread.sleep(40);
                        g.setColor(Color.white);
                        g.fillOval(x, 525, 10, 10);
                        g.setColor(Color.red);
                        g.drawLine(x, 530, 550, 530);

                    } catch (Exception e) {
                        System.err.println("" + e.getMessage());
                    }

                }
            }
        });
        animaThread.start();
    }
}
