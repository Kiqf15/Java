/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import com.sun.jdi.connect.spi.Connection;
import dao.Conexao;
import dao.DadosDAO;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;
import model.Modelo;
import model.ResultadosEletron;
import pkg222210114_kaique_fernandes_projeto.view.Principal;

/**
 *
 * @author kiq
 */
public class control {
    private Principal principal;
    private Modelo modelo;
    
    public control(Principal principal){
        this.principal = principal;
        this.modelo = new Modelo();
    }
    
    public void Dados(){
        double larg = Double.parseDouble(principal.getLarg().getText());
        double ni = Double.parseDouble(principal.getNi().getText());
        double nf = Double.parseDouble(principal.getNf().getText());
        double a = Double.parseDouble(principal.getA().getText());
        double b = Double.parseDouble(principal.getB().getText());
        
        double funcaoIR = modelo.funcaoInicialRaiz(larg);
        double funcaoFR = modelo.funcaoFinalRaiz(larg);
        double funcaoIS = modelo.funcaoInicialSeno(larg, ni);
        double funcaoFS = modelo.funcaoFinalSeno(larg, nf);
        
        double ejie = modelo.energiaDosNiveisJIEletron(larg, ni);
        double ejfe = modelo.energiaDosNiveisJFEletron(larg, nf);
        double eevie = modelo.energiaDosNiveisEvIEletron(larg, ni);
        double eevfe = modelo.energiaDosNiveisEvFEletron(larg, nf);
        
        double ejip = modelo.energiaDosNiveisJIProton(larg, ni);
        double ejfp = modelo.energiaDosNiveisJFProton(larg, nf);
        double eevip = modelo.energiaDosNiveisEvIProton(larg, ni);
        double eevfp = modelo.energiaDosNiveisEvFProton(larg, nf);
        
        double energiaFotonEletron = modelo.energiaFotonEletron(eevfe, eevie);
        double energiaFotonProton = modelo.energiaFotonEletron(eevfp, eevip);
        
        double freqE = modelo.frequenciaEletron(energiaFotonEletron);
        double freqP = modelo.frequenciaProton(energiaFotonProton);
        
        double lambdaE = modelo.lambdaEletron(energiaFotonEletron);
        double lambdaP = modelo.lambdaProton(energiaFotonProton);
        
        double velIE = modelo.velocidadeEletron(ejie);
        double velFE = modelo.velocidadeEletron(ejfe);
        double velIP = modelo.velocidadeEletron(ejip);
        double velFP = modelo.velocidadeEletron(ejfp);
        
        double BroglieIP = modelo.lambdaBroglieIProton(ejip);
        double BroglieFP = modelo.lambdaBroglieFProton(ejfp);
        double BroglieIE = modelo.lambdaBroglieIEletron(ejie);
        double BroglieFE = modelo.lambdaBroglieFEletron(ejfe);
        
        double probabilidadeI = modelo.probabilidadeInicial(larg, a, b, ni);
        double probabilidadeF = modelo.probabilidadeFinal(larg, a, b, nf);
        
        if (principal.getEletron().isSelected() == true){
            principal.getFuncaoInicial().setText(String.valueOf("ψ(x)= " + funcaoIR + " sen( " + funcaoIS + " * x )"));
            principal.getFuncaoFinal().setText(String.valueOf("ψ(x)= " + funcaoFR + " sen( " + funcaoFS + " * x )"));
            principal.getEnergiaQuanticaInicial().setText(String.format("%.3e" + "J, " + "%.3e"+ "Ev", ejie, eevie));
            principal.getEnergiaQuanticaFinal().setText(String.format("%.3e" + "J, " + "%.3e"+ "Ev", ejfe, eevfe));
            principal.getEnergiaFoton().setText(String.format(energiaFotonEletron + "Ev"));
            principal.getFrequencia().setText(String.format("%.3e",freqE));
            principal.getLambda().setText(String.format("%.3e",lambdaE));
            principal.getVelocidadeInicial().setText(String.format("%.3e",velIE));
            principal.getVelocidadeFinal().setText(String.format("%.3e",velFE));
            principal.getBroglieInicial().setText(String.format("%.3e" + "J",BroglieIE));
            principal.getBroglieFinal().setText(String.format("%.3e" + "J",BroglieFE));
            principal.getProbabilidade().setText(String.format("inicial:" + "%.3e" + "final:" + "%.3e",probabilidadeI, probabilidadeF));
        }
        else if (principal.getProton().isSelected() == true){
            principal.getFuncaoInicial().setText(String.valueOf("ψ(x)= " + funcaoIR + " sen( " + funcaoIS + " * x )"));
            principal.getFuncaoFinal().setText(String.valueOf("ψ(x)= " + funcaoFR + " sen( " + funcaoFS + " * x )"));
            principal.getEnergiaQuanticaInicial().setText(String.format("%.3e" + "J, " + "%.3e"+ "Ev", ejip, eevip));
            principal.getEnergiaQuanticaFinal().setText(String.format("%.3e" + "J, " + "%.3e"+ "Ev", ejfp, eevfp));
            principal.getEnergiaFoton().setText(String.format(energiaFotonProton + "Ev"));
            principal.getFrequencia().setText(String.format("%.3e",freqP));
            principal.getLambda().setText(String.format("%.3e",lambdaP));
            principal.getVelocidadeInicial().setText(String.format("%.3e",velIP));
            principal.getVelocidadeFinal().setText(String.format("%.3e",velFP));
            principal.getBroglieInicial().setText(String.format("%.3e" + "J",BroglieIP));
            principal.getBroglieFinal().setText(String.format("%.3e" + "J",BroglieFP));
            principal.getProbabilidade().setText(String.format("inicial:" + "%.3e" + "final:" + "%.3e",probabilidadeI, probabilidadeF));
        }
    }
    
    /*private void inserir(ResultadosEletron resultado) {
        ResultadosEletron operacao = new ResultadosEletron();
        Conexao conn = new Conexao();
        DadosDAO dao = new DadosDAO();

        try {
            java.sql.Connection connection = conn.getConnection();
            dao = new DadosDAO(connection);
            dao.inserirDB(resultado);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
    
    public void listarHistorico() {
        Conexao conn = new Conexao();
        try {
            java.sql.Connection connection = conn.getConnection();
            DadosDAO dao = new DadosDAO(connection);
            ArrayList<ResultadosEletron> operacoes = dao.consultarDB();
            String[] colunas = {"operacoes, resultados"};
            DefaultTableModel tableModel = new DefaultTableModel(colunas, 0);
            for (ResultadosEletron op : operacoes) {
                Object[] data = {op.getOperacoes(), op.getTratamento()};
                tableModel.addRow(data);
            }
            principal.getjTabbedPane1().setModel(tableModel);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }*/
}
