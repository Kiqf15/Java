/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import com.sun.jdi.connect.spi.Connection;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import model.ResultadosEletron;

/**
 *
 * @author kiq
 */
public class DadosDAO {
    private Connection conn;

    public DadosDAO() {
    }

    public DadosDAO(Connection conn) {
        this.conn = conn;
    }
    
    /*
    public void inserirDB(ResultadosEletron operacoes) throws SQLException, IOException {
        String sql = "INSERT INTO Banco_de_Dados(contas, resultado) VALUES (?,?)";

        for (int i = 0; i < operacoes.Tratamento().size(); i++ ) {
            PreparedStatement ps = this.conn.prepareStatement(sql);

            ps.setString(1, operacoes.Tratamento().get(i));
            ps.setDouble(2, operacoes.Operacoes().get(i));
            ps.execute();
        }
        conn.close();
    }
    
    public ArrayList<ResultadosEletron> consultarDB() throws SQLException {
        ArrayList<ResultadosEletron> eletron = new ArrayList<>();
        String sql = "SELECT * FROM Banco_de_Dados";
        PreparedStatement statement = this.conn.prepareStatement(sql);
        statement.execute();

        ResultSet rs = statement.getResultSet();

        while (rs.next()) {
            ResultadosEletron operacoes = new ResultadosEletron();
            operacoes.setTratamento(rs.getString("contas"));
            operacoes.setOperacoes(rs.getDouble("resultado"));
            eletron.add(operacoes);
        }
        //conn.close();
        return eletron;
    }
    
    public void inserirArquivo(ResultadosEletron operacoes) {
        try {
            FileWriter arquivo = new FileWriter("operacoes.txt", true);
            PrintWriter escritaArquivo = new PrintWriter(arquivo);

            for (int i = 0; i < operacoes.Tratamento().size(); i++) {
                escritaArquivo.println(operacoes.Tratamento().get(i) + "; " + operacoes.Operacoes().get(i) + "; " + (new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(Calendar.getInstance().getTime())));
            }

            arquivo.close();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }

    }
    
    public ArrayList<String> consultarArquivo() {
        ArrayList<String> operacoes = new ArrayList<>();
        try {
            FileReader arquivo = new FileReader("operacoes.txt");
            BufferedReader br = new BufferedReader(arquivo);

            String linha;
            while ((linha = br.readLine()) != null) {
                operacoes.add(linha);
            }

        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        return operacoes;
    }
    */
    
}
