/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.ArrayList;

/**
 *
 * @author kiq
 */
public class ResultadosEletron {
    double funcaoIR, funcaoFR, funcaoIS, funcaoFS, ejie, ejfe, eevie, eevfe, energiaFotonEletron, freqE, lambdaE,
            velIE, velFE, BroglieIE, BroglieFE, probabilidadeI, probabilidadeF, tratamento;
    private String operacoes;
    
    public ArrayList<Double> Operacoes(){
        ArrayList<Double> operacoes = new ArrayList<>();
        operacoes.add(this.getFuncaoIR());
        operacoes.add(this.getFuncaoFR());
        operacoes.add(this.getFuncaoIS());
        operacoes.add(this.getFuncaoFS());
        operacoes.add(this.getEjie());
        operacoes.add(this.getEjfe());
        operacoes.add(this.getEevie());
        operacoes.add(this.getEevfe());
        operacoes.add(this.getEnergiaFotonEletron());
        operacoes.add(this.getFreqE());
        operacoes.add(this.getLambdaE());
        operacoes.add(this.getVelIE());
        operacoes.add(this.getVelFE());
        operacoes.add(this.getBroglieIE());
        operacoes.add(this.getBroglieFE());
        operacoes.add(this.getProbabilidadeI());
        operacoes.add(this.getProbabilidadeF());
        
        return operacoes;
    }
    
    public ArrayList<String> Tratamento(){
        ArrayList<String> tratamento = new ArrayList<>();
        tratamento.add("Função de onda quântica inicial (raiz): ");
        tratamento.add("Função de onda quântica final (raiz): ");
        tratamento.add("Função de onda quântica inicial (seno): ");
        tratamento.add("Função de onda quântica final (seno): ");
        tratamento.add("Energia em Joule do nível inicial de elétron: ");
        tratamento.add("Energia em Joule do nível final de elétron: ");
        tratamento.add("Energia em EletronVolts do nível inicial de elétron: ");
        tratamento.add("Energia em EletronVolts do nível final de elétron: ");
        tratamento.add("Energia do Foton em EletronVolts: ");
        tratamento.add("Frequência do elétron: ");
        tratamento.add("Comprimento de onda do elétron: ");
        tratamento.add("Velocidade inicial do elétron: ");
        tratamento.add("Velocidade final do elétron: ");
        tratamento.add("Comprimento de onda de De Broglie do elétron (inicial): ");
        tratamento.add("Comprimento de onda de De Broglie do elétron (final): ");
        tratamento.add("Probabilidade Inicial: ");
        tratamento.add("Probabilidade Final: ");
        
        return tratamento;
    }

    public ResultadosEletron() {
    }

    public ResultadosEletron(double funcaoIR, double funcaoFR, double funcaoIS, double funcaoFS, double ejie, double ejfe, double eevie, double eevfe, double energiaFotonEletron, double freqE, double lambdaE, double velIE, double velFE, double BroglieIE, double BroglieFE, double probabilidadeI, double probabilidadeF) {
        this.funcaoIR = funcaoIR;
        this.funcaoFR = funcaoFR;
        this.funcaoIS = funcaoIS;
        this.funcaoFS = funcaoFS;
        this.ejie = ejie;
        this.ejfe = ejfe;
        this.eevie = eevie;
        this.eevfe = eevfe;
        this.energiaFotonEletron = energiaFotonEletron;
        this.freqE = freqE;
        this.lambdaE = lambdaE;
        this.velIE = velIE;
        this.velFE = velFE;
        this.BroglieIE = BroglieIE;
        this.BroglieFE = BroglieFE;
        this.probabilidadeI = probabilidadeI;
        this.probabilidadeF = probabilidadeF;
    }

    public double getFuncaoIR() {
        return funcaoIR;
    }

    public void setFuncaoIR(double funcaoIR) {
        this.funcaoIR = funcaoIR;
    }

    public double getFuncaoFR() {
        return funcaoFR;
    }

    public void setFuncaoFR(double funcaoFR) {
        this.funcaoFR = funcaoFR;
    }

    public double getFuncaoIS() {
        return funcaoIS;
    }

    public void setFuncaoIS(double funcaoIS) {
        this.funcaoIS = funcaoIS;
    }

    public double getFuncaoFS() {
        return funcaoFS;
    }

    public void setFuncaoFS(double funcaoFS) {
        this.funcaoFS = funcaoFS;
    }

    public double getEjie() {
        return ejie;
    }

    public void setEjie(double ejie) {
        this.ejie = ejie;
    }

    public double getEjfe() {
        return ejfe;
    }

    public void setEjfe(double ejfe) {
        this.ejfe = ejfe;
    }

    public double getEevie() {
        return eevie;
    }

    public void setEevie(double eevie) {
        this.eevie = eevie;
    }

    public double getEevfe() {
        return eevfe;
    }

    public void setEevfe(double eevfe) {
        this.eevfe = eevfe;
    }

    public double getEnergiaFotonEletron() {
        return energiaFotonEletron;
    }

    public void setEnergiaFotonEletron(double energiaFotonEletron) {
        this.energiaFotonEletron = energiaFotonEletron;
    }

    public double getFreqE() {
        return freqE;
    }

    public void setFreqE(double freqE) {
        this.freqE = freqE;
    }

    public double getLambdaE() {
        return lambdaE;
    }

    public void setLambdaE(double lambdaE) {
        this.lambdaE = lambdaE;
    }

    public double getVelIE() {
        return velIE;
    }

    public void setVelIE(double velIE) {
        this.velIE = velIE;
    }

    public double getVelFE() {
        return velFE;
    }

    public void setVelFE(double velFE) {
        this.velFE = velFE;
    }

    public double getBroglieIE() {
        return BroglieIE;
    }

    public void setBroglieIE(double BroglieIE) {
        this.BroglieIE = BroglieIE;
    }

    public double getBroglieFE() {
        return BroglieFE;
    }

    public void setBroglieFE(double BroglieFE) {
        this.BroglieFE = BroglieFE;
    }

    public double getProbabilidadeI() {
        return probabilidadeI;
    }

    public void setProbabilidadeI(double probabilidadeI) {
        this.probabilidadeI = probabilidadeI;
    }

    public double getProbabilidadeF() {
        return probabilidadeF;
    }

    public void setProbabilidadeF(double probabilidadeF) {
        this.probabilidadeF = probabilidadeF;
    }

    public double getTratamento() {
        return tratamento;
    }

    public void setTratamento(double tratamento) {
        this.tratamento = tratamento;
    }

    public String getOperacoes() {
        return operacoes;
    }

    public void setOperacoes(String operacoes) {
        this.operacoes = operacoes;
    }
    
    
    
}
