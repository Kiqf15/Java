/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author kiq
 */
public class Modelo {
    private double hj = 6.63e-34, hev = 4.14e-15, me = 9.11e-31, mp = 1.67e-27, c = 3e8;
    private double en, ef, lambda, frequencia, vel, Broglie, funcao, x;
    
    
    public double energiaDosNiveisJIEletron (double larg, double ni){
        return ((hj*hj)/(8*me*(larg*larg))) * (ni*ni);
    }
    public double energiaDosNiveisJFEletron (double larg, double nf){
        return ((hj*hj)/(8*me*(larg*larg))) * (nf*nf);
    }
    public double energiaDosNiveisEvIEletron (double larg, double ni){
        return (energiaDosNiveisJIEletron(larg, ni)/1.602e-19);
    }
    public double energiaDosNiveisEvFEletron (double larg, double nf){
        return (energiaDosNiveisJFEletron(larg, nf)/1.602e-19);
    }
    
    public double energiaDosNiveisJIProton (double larg, double ni){
        return ((hj*hj)/(8*mp*(larg*larg))) * (ni*ni);
    }
    public double energiaDosNiveisJFProton (double larg, double nf){
        return ((hj*hj)/(8*mp*(larg*larg))) * (nf*nf);
    }
    public double energiaDosNiveisEvIProton (double larg, double ni){
        return (energiaDosNiveisJIProton(larg, ni)/1.602e-19);
    }
    public double energiaDosNiveisEvFProton (double larg, double nf){
        return (energiaDosNiveisJFProton(larg, nf)/1.602e-19);
    }
    
    
    public double energiaFotonEletron(double efi, double ei){
        return ef = efi - ei;
    }
    public double energiaFotonProton(double efi, double ei){
        return ef = efi - ei;
    }
    
    
    public double frequenciaEletron(double ef){
        return frequencia = ef/hev;
    }
    public double frequenciaProton(double ef){
        return frequencia = ef/hev;
    }
    
    
    public double lambdaEletron(double ef){
        return lambda = hev*c / ef; 
    }
    public double lambdaProton(double ef){
        return lambda = hev*c / ef; 
    }
    
    
    public double velocidadeEletron(double en){
        return vel = Math.sqrt((2*en/me));
    }
    public double velocidadeProton(double en){
        return vel = Math.sqrt((2*en/mp));
    }
    
    
    public double lambdaBroglieIEletron(double ei){
        return Broglie = (hj/(Math.sqrt((2*me*ei))));
    }
    public double lambdaBroglieFEletron(double ef){
        return Broglie = (hj/(Math.sqrt((2*me*ef))));
    }
    public double lambdaBroglieIProton(double ei){
        return Broglie = (hj/(Math.sqrt((2*mp*ei))));
    }
    public double lambdaBroglieFProton(double ef){
        return Broglie = (hj/(Math.sqrt((2*mp*ef))));
    }
    
    
    public double funcaoInicialRaiz(double larg){
        return Math.sqrt((2/larg));
    }
    public double funcaoFinalRaiz(double larg){
        return Math.sqrt((2/larg));
    }
    public double funcaoInicialSeno(double larg, double ni){
        return (ni*Math.PI/larg);
    }
    public double funcaoFinalSeno(double larg, double nf){
        return (nf*Math.PI/larg);
    }
    
    public double probabilidadeInicial(double larg, double a, double b, double ni){
       return (2 / larg)
                * (((larg * Math.sin((2 * Math.PI * a * ni) / larg) - (2 * Math.PI * a * ni)) / (4 * Math.PI * ni))
                - (((larg * Math.sin((2 * Math.PI * b * ni) / larg) - (2 * Math.PI * b * ni)) / (4 * Math.PI * ni))));
    }
    public double probabilidadeFinal(double larg, double a, double b, double nf){
       return (2 / larg)
                * (((larg * Math.sin((2 * Math.PI * a * nf) / larg) - (2 * Math.PI * a * nf)) / (4 * Math.PI * nf))
                - (((larg * Math.sin((2 * Math.PI * b * nf) / larg) - (2 * Math.PI * b * nf)) / (4 * Math.PI * nf))));
    }
}
