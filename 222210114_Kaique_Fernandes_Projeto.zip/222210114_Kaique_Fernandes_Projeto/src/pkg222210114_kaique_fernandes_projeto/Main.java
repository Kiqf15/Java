/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg222210114_kaique_fernandes_projeto;

import pkg222210114_kaique_fernandes_projeto.view.Principal;

/**
 *
 * @author kiq
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Principal frm = new Principal();
        frm.setVisible(true);
    }
    
}
