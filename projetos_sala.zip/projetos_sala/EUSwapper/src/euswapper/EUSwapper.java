/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package euswapper;

import java.util.Scanner;

/**
 *
 * @author kaiqu
 */
public class EUSwapper {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Swapper troca = new Swapper();
        
        Scanner input = new Scanner(System.in);
        
        System.out.print("Digite o valor de X: ");
        troca.setX(input.nextDouble());
        System.out.print("Digite o valor de Y: ");
        troca.setY(input.nextDouble());
        
        troca.change();
        
        System.out.println("O novo valor de X é: " + troca.getX());
        System.out.println("O novo valor de Y é: " + troca.getY());
    }
    
}
